var xmlHttp = null;
var i = 0;
var emotion = 'anger';// can be set as joy

$(document).ready(function () {
    //getEmotionResponse();
    $('#chatList').append('<li class="mar-btm"><div class="media-left"><img src="chatbot.png" class="img-circle img-sm" alt="Profile Picture"></div><div class="media-body pad-hor"><div class="speech"><a href="#" class="media-heading">VZ Bot</a><p>Hello Lucy, how can I help you today ?</p><p class="speech-time"><i class="fa fa-clock-o fa-fw"></i>09:23AM</p></div></div></li>');
});

function getEmotionResponse()
{
    var customerQuery = document.getElementById( "textTyped" ).value;
    var url = "?query=" + customerQuery;

    // xmlHttp = new XMLHttpRequest(); 
    // xmlHttp.onreadystatechange = processResponse;
    // xmlHttp.open( "GET", url, true );
    // xmlHttp.send( null );
    $('#chatList').append('<li class="mar-btm"><div class="media-right"><img src="user.png" class="img-circle img-sm" alt="Profile Picture"></div><div class="media-body pad-hor speech-right"><div class="speech"><a href="#" class="media-heading">Lucy Doe</a><p>' + customerQuery + '</p><p class="speech-time"><i class="fa fa-clock-o fa-fw"></i> 09:23AM</p></div></div></li>');
    processResponse(customerQuery, i);
}

function processResponse(customerQuery) 
{
    if (emotion == 'anger') {
        var botResponse = '';
        switch(i) {
            case 0:
                botResponse = 'Sorry to hear, give us some time to check the records';
                break;
            case 1:
                botResponse = 'Apologies! We totally understand your concern. Payment failure is confirmed.' + 
                'We will plan for a refund soon while we will work towards improving the system.' + 
                'To value our customers, we would like to offer you a one time discount of 10% on next payment. Code will be sent via email';
                break;
            case 2:
                botResponse = 'We are sorry to hear!';
                break;
        }
        $('#chatList').append('<li class="mar-btm"><div class="media-left"><img src="chatbot.png" class="img-circle img-sm" alt="Profile Picture"></div><div class="media-body pad-hor"><div class="speech"><a href="#" class="media-heading">VZ Bot</a><p>'+ botResponse + '</p><p class="speech-time"><i class="fa fa-clock-o fa-fw"></i>09:23AM</p></div></div></li>');
        i = i + 1;
    } else {
        var botResponse = '';
        switch(i) {
            case 0:
                botResponse = 'That\'s just awesome. We are as excited as you. Currently we have our best offering for you.' +
                'Play More Unlimited Plan! Starting at $45 only. Limited time offer. Exclusively for you.';
                break;
            case 1:
                botResponse = 'Excellent choice. We will get started right away. Your request for plan change has been processed.' +
                'We welcome you to the 5G family. For premium customers like you, the 5G experience will provide you faster downloads with lightning speed on your iPhone 12 Pro';
                break;
            case 2:
                botResponse = 'Good to know!';
                break;
        }
        $('#chatList').append('<li class="mar-btm"><div class="media-left"><img src="chatbot.png" class="img-circle img-sm" alt="Profile Picture"></div><div class="media-body pad-hor"><div class="speech"><a href="#" class="media-heading">VZ Bot</a><p>'+ botResponse + '</p><p class="speech-time"><i class="fa fa-clock-o fa-fw"></i>09:23AM</p></div></div></li>');
        i = i + 1;
    }
    // if ( xmlHttp.readyState == 4 && xmlHttp.status == 200 ) 
    // {
    //     if ( xmlHttp.responseText == "Not found" ) 
    //     {
    //         document.getElementById( "TextBoxCustomerName").value = "Not found";
    //         document.getElementById( "TextBoxCustomerAddress" ).value = "";
    //     }
    //     else
    //     {
    //         var info = eval ( "(" + xmlHttp.responseText + ")" );   
    //         document.getElementById("TextBoxCustomerName").value = info.jsonData[0].cmname;
    //         document.getElementById("TextBoxCustomerAddress").value = info.jsonData[0].cmaddr1;
    //     }                  
    // }
}